<?php

function check(){

$getcon=file_get_contents(plugin_dir_path(__FILE__).'lisense.json');
$datacon=json_decode($getcon);

if(! $datacon->date==date('yy-m-d')){
    
     $postRequest = [
       "Lisense"=>"3",
        "email" => $datacon>email,
        "lisense_key"=>$datacon->lisense_key
    ];


    $cURLConnection = curl_init('https://theonlinevoting.com/Autoindex/lisense.php');
    curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
    curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

    $apiResponse = curl_exec($cURLConnection);
    curl_close($cURLConnection);

file_put_contents(plugin_dir_path(__FILE__)."lisense.json",$apiResponse); 
    
}






}

// check();

$get=file_get_contents(plugin_dir_path(__FILE__).'settings.json');
$data=json_decode($get);
$site=$data->url;

$bingapi=$data->bingapi;
$file=$data->google_json_file;
$email=$data->email;
$url=$data->url;
$permalink = get_permalink( $id );
include_once('bingtest.php');
//checkcredentials();



if($data->enable_google=='on'){

   $result=google($url,$file,$email,$permalink);


}
if($data->enable_bing=='on'){

  //  $result=bing($site,$permalink,$bingapi,$email);

}







?>