<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title></title>
    <link data-require="datatables@*" data-semver="1.10.12" rel="stylesheet" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
    <link data-require="font-awesome@*" data-semver="4.5.0" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.css" />
    <link data-require="bootstrap-css@3.3.6" data-semver="3.3.6" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.css" />

    <script data-require="jquery" data-semver="3.0.0" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.js"></script>
    <script data-require="datatables@*" data-semver="1.10.12" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="style.css" />
    <script src="script.js"></script>
</head>

<body>

<?php
$configapi=file_get_contents(plugin_dir_path(__FILE__).'../api/config.json');
$configapi=json_decode($configapi);
$api_url=$configapi->logs;



?>

<br/>
<table id="example" class="display" cellspacing="0" width="100%">
    <thead>
    <tr>

        <th>Url</th>
        <th>Status</th>
        <th>Code</th>
        <th>Type</th>
        <th>Date</th>
    </tr>
    </thead>


    <tbody>

    <?php

    $get=file_get_contents(plugin_dir_path(__FILE__).'settings.json');
    $data=json_decode($get);

    $email=$data->email;

    $postRequest = [
            "logs"=>1,
        "email" => $email
    ];


    $cURLConnection = curl_init($api_url);
    curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
    curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

    $apiResponse = curl_exec($cURLConnection);
    curl_close($cURLConnection);



    $i=1;
    foreach (json_decode($apiResponse) as $data)
    {

        ?>
        <tr>

            <th><?php echo $data->url; ?></th>
            <th><?php echo $data->status; ?></th>
            <th><?php echo $data->code; ?></th>
            <th><?php echo $data->type; ?></th>
            <th><?php echo $data->date; ?></th>
        </tr>

    <?php } ?>

    </tbody>
</table>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>

</body>

</html>
