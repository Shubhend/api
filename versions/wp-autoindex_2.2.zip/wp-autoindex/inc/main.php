<?php


$notification=@file_get_contents(plugin_dir_path(__FILE__).'notification.json');
$notification=json_decode($notification);

$getlic=@file_get_contents(plugin_dir_path(__FILE__).'lisense.json');
$datalic=json_decode($get);

if($datalic->valid==0){
    
    //  add_action( 'admin_notices', 'sample_admin_notice__error_license' );
}

if($notification->request_notify){
    add_action( 'admin_notices', 'sample_admin_notice__error_notification' );

}


function sample_admin_notice__error_notification(){
    $get=@file_get_contents(plugin_dir_path(__FILE__).'notification.json');
    $data=json_decode($get);
    $class = 'notice notice-error';
    if($data->valid==0){
        $message = __( $data->request_notify, 'sample-text-domain' )."  <a href='" .admin_url( 'admin.php?page=lisense')."' >Click Here</a>";

        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ),  $message  );

    }


}

function sample_admin_notice__error_license(){
      $get=@file_get_contents(plugin_dir_path(__FILE__).'lisense.json');
    $data=json_decode($get);
    $class = 'notice notice-error';
    if($data->valid==0){
        $message = __( $data->msg, 'sample-text-domain' )."  <a href='" .admin_url( 'admin.php?page=lisense')."' >Click Here</a>";

        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ),  $message  );

    }

    
}



?>