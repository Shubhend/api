<?php


    function checkcredentials(){
        $get=file_get_contents(plugin_dir_path(__FILE__).'config.txt');
        $data=json_decode($get);
        $email=$data->email;

        $postRequest = [
            "check"=>"3",
            "email"=>$email,
            "version"=>'1.10.3'

        ];


        $cURLConnection = curl_init('https://theonlinevoting.com/Autoindex/auto-index.php');
        curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
        curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

        $apiResponse = curl_exec($cURLConnection);
    
        curl_close($cURLConnection);

        $apiResponse=json_decode($apiResponse);

        if($apiResponse->error==0){

            $data=[];
            $data['s_f']=$apiResponse->s_f;
            $data['s_f_t']= $apiResponse->s_f_t;
            $data['s_n']=$apiResponse->s_n;
            $data['s_n_t']=$apiResponse->s_n_t;
            $data['un_verified']=$apiResponse->un_verified;
            $data['verify_mesg']=$apiResponse->verify_mesg;

            file_put_contents(plugin_dir_path(__FILE__).'mainconfig.txt',json_encode($data));


        }

    }


    function updatesitejson(){



    }

    function google($site,$path,$email,$perma=null){

        $configapi=file_get_contents(plugin_dir_path(__FILE__).'../api/config.json');
        $configapi=json_decode($configapi);
        $api_url=$configapi->request_api;

if(! $perma){
   $perma=$site;
}

$send=[];
$send['err']=1;

// service_account_file.json is the private key that you created for your service account.


        $postRequest = [
            "type"=>"google",
            "email" => $email,
            "site" =>$site,
            "link" => $perma,
            "google_file"=>base64_encode($path)
        ];


        $cURLConnection = curl_init($api_url);
        curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
        curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

        $apiResponse = curl_exec($cURLConnection);
        curl_close($cURLConnection);


        if(isset(json_decode($apiResponse)->notification)){


            file_put_contents(plugin_dir_path(__FILE__).'notification.json',json_encode(["request_notify"=>json_decode($apiResponse)->notification],JSON_PRETTY_PRINT));

        }


        return json_decode($apiResponse);


            }
            function bing($site,$link,$api,$email){



                $configapi=file_get_contents(plugin_dir_path(__FILE__).'../api/config.json');
                $configapi=json_decode($configapi);
                $api_url=$configapi->request_api;



                $postRequest = [
                    "type"=>"bing",
                    "email" => $email,
                    "site" =>$site,
                    "link"=>$link,
                    "bing_ap"=>base64_encode($api)
                ];


                $cURLConnection = curl_init($api_url);
                curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
                curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

                $apiResponse = curl_exec($cURLConnection);
                curl_close($cURLConnection);
                if(isset(json_decode($apiResponse)->notification)){


                    file_put_contents(plugin_dir_path(__FILE__).'notification.json',json_encode(["request_notify"=>json_decode($apiResponse)->notification],JSON_PRETTY_PRINT));

                }

                  return json_decode($apiResponse);

            }



?>