<!DOCTYPE html>
<html lang="en">
<head>
  <title>Autofast Index </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>


<?php


$configapi=file_get_contents(plugin_dir_path(__FILE__).'../api/config.json');
$configapi=json_decode($configapi);
$api_url=$configapi->api_url;




if(isset($_POST['testbing'])){
    include_once('bingtest.php');
    $get=file_get_contents(plugin_dir_path(__FILE__).'settings.json');
    $data=json_decode($get);
     $site=$data->url;
      $bingapi=$data->bingapi;
  //  $file=$data->google_json_file;
    $email=$data->email;


    $result=bing($site,$site,$bingapi,$email);


    echo "<div class='notice notice-success'>".$result->msg."</div>";



}
if(isset($_POST['testgoogle'])){
    include_once('bingtest.php');
    $get=file_get_contents(plugin_dir_path(__FILE__).'settings.json');
    $data=json_decode($get);
    $site=$data->url;
    $email=$data->email;

    $file=$data->google_json_file;


   // var_dump($bingurl);

    $result=google($site,$file,$email);
    echo "<div class='notice notice-success'>".$result->msg."</div>";
}


if(isset($_POST['submit'])){

    $url=$_POST['url'];
    $bingapi=$_POST['bingapi'];

    $target_dir = plugin_dir_path(__FILE__)."upload/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $uploadOk = 1;

    $data=[];
    $data["url"]=$url;
    $data["bingapi"]=$bingapi;
    $data['enable_bing']=$_POST['enable_bing'];
    $data['enable_google']=$_POST['enable_google'];
    $data['email']=$_POST['email'];
    $email=$_POST['email'];



        $data['google_json_file']=  $_POST['google_json_value'];
     //   file_put_contents(plugin_dir_path(__FILE__).'settings.json','');


        file_put_contents(plugin_dir_path(__FILE__).'settings.json',json_encode($data,JSON_PRETTY_PRINT));



    $postRequest = [
       "add"=>"3",
        "email" => $email,
        "site" =>$url,
        "version"=>'1.10.3'
    ];


    $cURLConnection = curl_init($api_url);
    curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
    curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

    $apiResponse = curl_exec($cURLConnection);
    curl_close($cURLConnection);



}


?>

<?php
if(file_exists(plugin_dir_path(__FILE__).'settings.json')){
    $get=file_get_contents(plugin_dir_path(__FILE__).'settings.json');
    $data=json_decode($get);
    $email=$data->email;
    $site=$data->url;
    $enablegoogle=$data->enable_google;
    $enablebing=$data->enable_bing;
    $bingapi=$data->bingapi;
    $file=$data->google_json_file;

}


?>
<div class="container">
  <h2>AutoFast Indexing Settings</h2>
  <form class="form-horizontal" method="post" enctype="multipart/form-data" >
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" value="<?php echo $email; ?>" placeholder="Enter email" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Site:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="url" placeholder="https://" name="url" value="<?php echo $site; ?>">
      </div>
    </div>

<div class="form-group">     
 <label class="control-label col-sm-2" for="pwd">Enable Api:</label>   
      <div class="col-sm-offset-2 col-sm-10">
        <div class="checkbox">
            <?php if($enablegoogle=='on'){ ?>
          <label><input type="checkbox"   name="enable_google" checked> Google Indexing</label>
            <?php }else{ ?>
                <label><input type="checkbox"   name="enable_google"> Google Indexing</label>

            <?php } ?>
        </div>
         <div class="checkbox">

             <?php if($enablebing=='on'){ ?>
                 <label><input type="checkbox" id="check"   name="enable_bing" checked>Bing Indexing</label>


             <?php }else{ ?>
                 <label><input type="checkbox"  id="check" name="enable_bing">Bing Indexing</label>

             <?php } ?>


         </div>
      </div>


    </div>

      <div class="form-group">
          <label class="control-label col-sm-2" for="pwd"></label>
          <b>Steps to Generate Google json key and Bing Api key <a href="https://firstpageranker.com/wpautoindex.php"> Click here</a></b>

      </div>



 <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Bing Api Key:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="pwd" placeholder="" name="bingapi" value="<?php echo $bingapi; ?>">
      </div>
    </div>

 <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Upload Google Json:</label>
      <div class="col-sm-10">

          <input id="background_image" name="google_json_value" type="text" name="background_image" value="<?php echo $file ?>" />
          <input id="upload_image_button" type="button" class="button-primary" value="Insert Json File" />


      </div>
    </div>


    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>

<div class="row">
    <?php if($enablebing=='on'){ ?>
          <form method="post">
            <input type="hidden" name="site" value="<?php echo $site; ?>"/>
            <button type="submit" name="testbing" class="btn btn-default">Test Bing</button>

        </form>

    <?php } ?>
    <?php if($enablegoogle=='on'){ ?>
        <form method="post">
            <input type="hidden" name="site" value="<?php echo $site; ?>"/>
            <button type="submit" name="testgoogle" class="btn btn-default">Test Google</button>

        </form>

    <?php } ?>


</div>

    <div class="form-group">
        <label class="control-label col-sm-2" for="pwd"> Need Help to setup?  </label>
        <div class="responsive-video">

            <iframe src="https://www.youtube.com/embed/OPrYhDM74LA?autoplay=0&amp;controls=1&amp;rel=0&amp;autohide=1&amp;nologo=1&amp;showinfo=0&amp;" width="100%" height="380"></iframe>
        </div>
    </div>


</div>
<script type="text/javascript">

    $('#check').change(function(e) {
        $(e).val($(this).is(':checked'));
        if($(e).val()==1){
            $(e).val(0);
        }else{
            $(e).val(1);
        }

    });


</script>

<script type="text/javascript">

    jQuery(document).ready(function($){
        var mediaUploader;
        $('#upload_image_button').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Choose Json',
                button: {
                    text: 'Choose Json File'
                }, multiple: false });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#background_image').val(attachment.url);
            });
            mediaUploader.open();
        });
    });

</script>

</body>
</html>
