<!DOCTYPE html>
<html lang="en">
<head>
  <title>Lisense</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>


<?php

$configapi=file_get_contents(plugin_dir_path(__FILE__).'../api/config.json');
$configapi=json_decode($configapi);
$api_url=$configapi->license_url;


if(! file_exists(plugin_dir_path(__FILE__).'settings.json')){

    $message = __( 'Please Register, ', 'sample-text-domain' )."  <a href='" .admin_url( 'admin.php?page=Autoindex')."' >Click Here</a>";
    $class = 'notice notice-error';
    printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ),  $message  );

    exit;
}



if(isset($_POST['submit'])){




    $email=$_POST['email'];
    $bingapi=$_POST['lisense_key'];
    $url=$_POST['url'];



    $postRequest = [
       "Lisense"=>"3",
        "email" => $email,
        "lisense_key"=>$bingapi,
        "url"=>$url,
        "date"=> date('yy-m-d')
    ];


    $cURLConnection = curl_init($api_url);
    curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
    curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

    $apiResponse = curl_exec($cURLConnection);
    curl_close($cURLConnection);

    file_put_contents(plugin_dir_path(__FILE__)."lisense.json",'');

    file_put_contents(plugin_dir_path(__FILE__)."lisense.json",$apiResponse);

    $apiResponse=json_decode($apiResponse);


    if($apiResponse->valid==0){

        $data['request_notify']=$apiResponse->msg;
        file_put_contents(plugin_dir_path(__FILE__)."notification.json",json_encode($data));


        echo "<div class='notice notice-error'>".$apiResponse->msg."</div>";
    }else {
        $data['request_notify']='';
        file_put_contents(plugin_dir_path(__FILE__)."notification.json",json_encode($data));


        echo "<div class='notice notice-success'>Success</div>";

    }



    // echo $url;


}


?>

<?php
if(file_exists(plugin_dir_path(__FILE__).'lisense.json')){
    $get=file_get_contents(plugin_dir_path(__FILE__).'lisense.json');
    $data=json_decode($get);
    $lisense_key=$data->lisense_key;
    $valid=$data->valid;

}

if(file_exists(plugin_dir_path(__FILE__).'settings.json')){
    $get=file_get_contents(plugin_dir_path(__FILE__).'settings.json');
    $data=json_decode($get);
    $email=$data->email;
    $url=$data->url;

}
?>


<div class="container">
  <h2>AutoFast Indexing Lisense</h2>
  <form class="form-horizontal" method="post" enctype="multipart/form-data" >
    <div class="form-group" style="display:none;">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" name="email" id="email" style="display:none;" value="<?php echo $email; ?>" placeholder="Enter email" name="email">
      </div>
    </div>




   <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Lisense Key:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="pwd" placeholder="" name="lisense_key" value="<?php echo $lisense_key; ?>">
      </div>
    </div>


      <div class="form-group" style="display:none;">
          <label class="control-label col-sm-2" for="pwd">Site Url:</label>
          <div class="col-sm-10">
              <input type="text" class="form-control"  id="pwd" placeholder="" style="display:none;" name="url" value="<?php echo $url; ?>">
          </div>
      </div>

      <label class="control-label col-sm-2" for="pwd">Generate Lisense: <a target="_blank" href="http://firstpageranker.com/payment.php"> Click here </a></label>


    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>

</div>
<script>

    $('#check').change(function(e) {
        $(e).val($(this).is(':checked'));
        if($(e).val()==1){
            $(e).val(0);
        }else{
            $(e).val(1);
        }

    });


</script>


<script>

  </script>

</body>
</html>
